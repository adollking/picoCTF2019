package androidx.lifecycle;

public interface LifecycleObserver {
}
